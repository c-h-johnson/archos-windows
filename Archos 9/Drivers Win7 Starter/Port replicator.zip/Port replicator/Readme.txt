LAN9500 NDIS Driver v2.03.0004.0000 for Windows (32 bit & 64 bit)
=================================================================

   *** 5/16/2009  - Windows Xp / Windows Vista / Windows 7 ***

This file provides information about v2.03.0004.0000 release of the Ndis drivers 
for Windows Operating Systems (32 bit & 64 bit) for the LAN9500 device.

Contents
--------
A. Windows Operating systems Supported
B. Automated Installer based instructions
C. INF based installation instructions
D. Driver Configurable Parameters
E. Release History

A. Windows Operating systems Supported
--------------------------------------
This distribution contains drivers compliant to the NDIS 5.1 specification
which have been certified by Microsoft Windows Hardware Quality Labs  
(submission 1329178) for the following Windows Operating Systems:
- Windows XP SP3 (32 bit) 
- Windows XP SP2 (64 bit)
- Windows Vista SP1 (32 bit)
- Windows Vista SP1 (64 bit)
- Windows 7 (32 bit) - MSFT WHQL Certified with Win7 Release Candidate 7100
- Windows 7 (64 bit) - MSFT WHQL Certified with Win7 Release Candidate 7100
(See http://winqual.microsoft.com/LogoVerificationReport.aspx?sid=1329178
for further details on WHQL certification)

B. Automated Installer based instructions
-----------------------------------------
If you received this driver package as a self extracting autolaunch executable the
installation will have started automatically upon execution. Follow the on screen 
instructions. 

Note that the automated installer can also be started in quiet mode (no dialogues or 
prompt) by decompressing the package contents (it's a Winzip self executable file) 
and running the following command line from it's root "installer /q /se"

When installing the device on Windows Vista or Windows 7 this will provide a seamless 
automated install experience whether you run the installer software first and then 
plug the device, or do it in the reversed order.

When installing the device on Windows Xp there are a few tips to follow that will 
make your automated installer experience better:
- If this is a first time install for this device we recommend running the software 
  installation prior to pluging in the device.  The "Found new hardware" Wizard will 
  still pop up again later when you plug in your device but at that time you can just 
  let the wizard search for the drivers itself and it will find and install them 
  without a need to browse for the storage location.
- If the device was already installed the installation will properly update the driver.

Automated installer package contents:
\Readme.txt                             -   This file
\install.exe                            -   EXE that checks the platform and launches the 
                                            appropriate DPInst executable for the architecture
                                            (see below).
\x86\DpInstx86.exe                      -   Microsoft redistributable Driver Package installer
                                            utility for x86
\x86\DpInst.xml                         -   DPInst configuration/customization file.
\x86\AppData\Eula409.txt                -   End User License Agreement Text
\x86\AppData\watermark.bmp              -   Left margin watermark bitmap
\x86\AppData\logo.bmp                   -   Company or device logo bitmap
\x86\Driver\net9500-x86-n51f.inf        -   NDIS 5.1 driver installation file for x86
\x86\Driver\lan9500-x86-n51f.cat        -   NDIS 5.1 driver WHQL-signed catalog file for x86
\x86\Driver\lan9500-x86-n51f.sys        -   NDIS 5.1 driver file for x86
\x86\Driver\WdfCoInstaller01007.dll     -   MSFT's Wdf Coinstaller v1.7 for x86

\x64\DpInstx64.exe                      -   Microsoft redistributable Driver Package installer 
                                            utility for x64
\x64\DpInst.xml                         -   DPInst configuration/customization file.
\x64\AppData\Eula409.txt                -   End User License Agreement Text
\x64\AppData\watermark.bmp              -   Left margin watermark bitmap
\x64\AppData\logo.bmp                   -   Company or device logo bitmap
\x64\Driver\net9500-x64-n51f.inf        -   NDIS 5.1 driver installation file for x64
\x64\Driver\lan9500-x64-n51f.cat        -   NDIS 5.1 driver WHQL-signed catalog file for x64
\x64\Driver\lan9500-x64-n51f.sys        -   NDIS 5.1 driver file for x64
\x64\Driver\WdfCoInstaller01007.dll     -   MSFT's Wdf Coinstaller v1.7 for x64

C. INF based installation instructions
--------------------------------------
If you received this driver package as a zip file containing just sys, inf, cat, dll and 
this readme.txt file you need to do an "INF based" install.

1.  Plug the USB cable to the PC's USB host port and the other end to the USB connector.
2.  After booting, Windows will pop up a "Found New hardware" Wizard. Follow the 
    onscreen instructions answering the questions to instruct Windows NOT to search 
    for drivers and that you will provide them yourself. Enter the path to the Drivers 
    subdirectory of the root of this distribution (where the sys and inf driver files 
    are located) and let Windows complete the installation process as usual for any 
    network interface card.

INF based package contents:
\Readme.txt                             -   This file

\x86\Driver\net9500-x86-n51f.inf        -   NDIS 5.1 driver installation file for x86
\x86\Driver\lan9500-x86-n51f.cat        -   NDIS 5.1 WHQL-signed catalog file for x86 
\x86\Driver\lan9500-x86-n51f.sys        -   NDIS 5.1 driver file for x86
\x86\Driver\WdfCoInstaller01007.dll     -   MSFT's Wdf Coinstaller v1.7 for x86

\x64\Driver\net9500-x64-n51f.inf        -   NDIS 5.1 driver installation file for x64
\x64\Driver\lan9500-x64-n51f.cat        -   NDIS 5.1 WHQL-signed catalog file for x64 
\x64\Driver\lan9500-x64-n51f.sys        -   NDIS 5.1 driver file for x64
\x64\Driver\WdfCoInstaller01007.dll     -   MSFT's Wdf Coinstaller v1.7 for x64

D. Driver Configurable Parameters
---------------------------------
The following parameters are configurable thru the LAN95000 Advanced properties page:

1. Media Type: Selection of one of the following ennumerated values
               -All Modes Autodetect:        Advertises support for 4 combos of 10/100 and HD/FD
               -Autodetect 10HD:             Restricts capabilities to 10HD and autonegotiates
               -Autodetect 10FD:             Restricts capabilities to 10FD and autonegotiates
               -Autodetect 100HD:            Restricts capabilities to 100HD and autonegotiates
               -Autodetect 100FD:            Restricts capabilities to 100FD and autonegotiates
               -Autodetect Custom:           Advertises Capabilities according to Custom Capabilities
               -Force 10HD:                  Forces 10HD without autonegotiating
               -Force 10FD:                  Forces 10FD without autonegotiating
               -Force 100HD:                 Forces 100HD without autonegotiating
               -Force 100FD:                 Forces 100FD without autonegotiating

2. Media Type Custom Capabilities (hex): - 16bit hex value that specifies the contents of the 
                                           Autonegotiation advertisement register of the MII Phy. 
                                         - Only meaningful if MediaType = Autodetect Custom.

3. Flow Control: Configure flow control advertised capabilities
                 -Disabled
                 -Generate and Respond
                 -Generate only
                 -Respond only

4. Network Address (optional): Allows overiding the MAC address of the device

5. Priority & VLAN: Enable or Disable support for VLAN tagging. 
                    - Priority & VLAN Enabled
                    - Priority & VLAN Disabled

6. VLANID: If "Priority & VLAN" are enabled this value selects the VLANID
           to insert on transmits and to filter upon on receives.

7. USBBandwidthMode: Selects how the driver uses USB bandwidth
                     - Maximum Throughput: Uses as much USB bandwidth as it needs to maximize the LAN9500's 
                                           device networking performance.
                     - Sharing Friendly:   While providing adequate networking performance, in this mode 
                                           the driver is conservative with USB bandwidth usage for a 
                                           better experience of other devices with which it shared USB
                                           bandwidth.
                     - Automatic:          Sets itself to Sharing for High speed, and to Maximum Throughput 
                                           for full speed.

Release History
---------------

** v2.03.0004.0000 ** Package Updated 5/16/2009

- "Unidriver Model" package certified with WHQL logo for Windows 7, Windows Vista 
  and Windows Xp -> replaced *.CAT files with new ones received from MSFT WHQL.
- INFs' DriverVer date changed from 2/06/09 to 5/06/09 for Win7 WHQL logo submission
  since Win7 requires a DriverVer dated post 4/21/2009 (Win7 RC 7100 release date).
- No changes in driver binary (sys) files

** v2.03.0004.0000 ** Package Updated 4/08/2009

- <arch>\AppData\Eula409.txt updated as per latest SMSC agreement authorizing end 
  user distribution.
- No changes in driver packages

** v2.03.0004.0000 ** Original Package 2/16/2009

(Cumulative changes since 2.02.0000.0000)

- Specify device as Safely surprise removable, so it dissappears from the "Safe Remove hardware" app
- Added support for new SKUs, and boards that use separate Link and activity LEDs.
- Fixed some statistic counter bugs.
- Pruning system event log messages that were indicating nonfunctioning device even if the driver
  had successfully recovered from the error condition.
- Fix bug where the system becomes unresponsive if unplug device while stressful traffic (i.e. smartbits 
  NIC test) ongoing
- Add USB Bandwidth Mode advanced properties parameter, defaults to USB bandwidth sharing friendly.
- Fixes in Vista to allow the device to consume power level as low as in Xp when it is disabled.
- Improvements to synchronization mechanisms in both transmit and receive using less locking.
- Additions to IOCTL interface for LAN9500Utility support. Synchronize IOCTL PHY access with
  driver internal PHY access.
- Multiple stability fixes as per guidelines from DDC2008, code reviews and other sources.
- Improvements to Tx path for better pipelining.
- Improvements on Rx for better USB bandwidth usage.
- Add VLAN support
- Fix for issue where an oversized ethernet packet caused a USB babble error when the driver 
  operates in single packet receive mode.
- Error recovery fixes:
   + Do proper TXE recovery via LRST since flushing the Tx path is not enough
   + Fix Tx & Rx disable sequence. 
   + Fix bug that was causing triple pipe reset when only one was needed.
   + Invoke reset recovery on Tx underun / Tx overrun.
- Initial rev of Win32 DPInst Dispatcher application (install.exe) included
- Upgraded DPInst to WDK 6001.18002's shipping version (2.1.1)

** v2.02.0001.0000 thru 2.03.03.0005 **
Internal releases.

** v2.02.0000.0000 **

- Initial WDF release WHQL certified for Windows Xp and Windows Vista.

Known Issues
------------

** v2.03.0004.0000 **

None new known at this time (the ones mentioned for 2.02.0000.0000 below remain).

** v2.02.0000.0000 **

1. The automated installer package is based on Microsoft's DpInst application. It's DpInst.xml file 
   has been populated with the <suppressAddRemovePrograms/> element. Therefore no entry is added in 
   "Add/Remove Programs" (Windows Xp) or "Programs and Features" (Windows Vista) when the driver 
   package is installed. Uninstallation of the driver can be achieved by right clicking and selecting 
   "Uninstall" from the device manager entry for the LAN9500 device.

   This has been done because of the following to know problems in Microsoft's DPInst solution:

   1.1 Automated installer package does not properly remove driver from Device manager on uninstallation
   under Windows Vista.

   Description:
   The automated installer creates entries in the "Programs and Features" installed software list during 
   installation. When this entry is used to uninstall it, the driver package will be removed from the 
   lists, however the device will not be removed from Device Manager.

   Diagnostic:
   There is due to a bug in the Microsoft WDF coinstaller v1.7 (WdfCoInstaller01007.dll) that prevents 
   the DPInst application from  properly uninstalling WDF drivers in Windows Vista.

   Workaround:
   After completing the uninstallation from the installed software lists mentioned above, the device 
   can be removed from Device manager by right clicking on it and selecting "uninstall".

   Note that this problem does not occur in Windows Xp

   1.2 Automated installer package does not properly uninstall driver if the device is not plugged in during 
   uninstallation for either Windows Vista or Windows Xp.

   Description:
   The automated installer creates entries in the "Add/Remove Programs" (Windows Xp) or "Programs and Features" 
   (Windows Vista) installed software list during installation. If the device is not presently plugged in the
   system, when this entry is used to uninstall it, the driver package will be removed from the lists, however 
   the device will not be uninstalled and will reappear in Device Manager as if had not been removed when plugged 
   back in.

   Diagnostic:
   There is a bug in DpInst that prevents it from uninstalling the driver when the device is not present.

   Workaround:
   After completing the uninstallation from the installed software lists mentioned above, the device 
   can be removed from Device manager by right clicking on it and selecting "uninstall".

2. Directory structures were rearranged in release v2.02.0000.0000 and there are duplicated files.
   
   This rearrangement, locating the x86 and x64 version of DPInst in separate folders was done 
   to overcome two DPInst issues:
   
   2.1 Mismatched architecture packages being installed (x64 in x86 system, x86 in x64 system)
   leaving two entries in Add/Remove Programs when DPInst app sees both x86 and x64 packages

   Diagnostic:
   There is a bug in DpInst that causes the mismatched architecture installation

   Workaround:
   As done in the v2.02.0000.0000 release, rearrange folders so that each DPInst only
   "sees" the driver for it's architecture only.

   2.2 DPInst complains of the driver non being WHQL-logo'ed in x64 version of Windows Xp even 
   though it is if it sees an x86 version of the driver. 

   Diagnostic:
   There is a bug in DpInst that causes the logo warning on the mismatched x86 architecture 
   installation

   Workaround:
   As done in the v2.02.0000.0000 release, rearrange folders so that each DPInst only
   "sees" the driver for it's architecture only.

These four issues have been reported to Microsoft and are being actively pursued for a fix.